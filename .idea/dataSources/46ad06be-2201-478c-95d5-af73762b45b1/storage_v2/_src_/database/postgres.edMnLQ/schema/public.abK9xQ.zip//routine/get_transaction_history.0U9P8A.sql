create function get_transaction_history(parameters json) returns json
    immutable
    strict
    language plv8
as
$$
try{

    var sqlstr = `
    SELECT 
		id,
		active,
		transactionname,
		to_char(transactiontime,'YYYY-MM-DD HH24:MI:SS') AS transactiontime,
		transactiontype,
		functionname,
		employeeid,
		division,
		company,
		facility,
		department,
		workcenter,
		application,
		operationcode,
		source,
		machinename
    FROM transaction_history
		WHERE active = 1
		ORDER BY transactiontime DESC
    limit ${parameters.limit} offset ${parameters.offset} `;
		
    var json_result = plv8.execute(sqlstr);
    return json_result;
		
}catch(e){
    return {"error":e.message,"sql":sqlstr};
}
$$;

alter function get_transaction_history(json) owner to postgres;

