create function insert_employee(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var str_sql = `INSERT INTO EMPLOYEE(name, employeeno, loginname, department, createdon, createdby, resourceid) VALUES('{data.name}', '{data.employeeno}', 
		'{data.loginname}','{data.department}', '{data.createdon}', '{data.createdby}', {data.resourceid})`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function insert_employee(json) owner to postgres;

