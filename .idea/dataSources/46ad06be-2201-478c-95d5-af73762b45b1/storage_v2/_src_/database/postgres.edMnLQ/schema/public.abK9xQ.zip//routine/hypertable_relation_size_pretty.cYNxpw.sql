create function hypertable_relation_size_pretty(main_table regclass)
    returns TABLE(table_size text, index_size text, toast_size text, total_size text)
    stable
    strict
    language plpgsql
as
$$
DECLARE
        table_name       NAME;
        schema_name      NAME;
BEGIN
        RETURN QUERY
        SELECT pg_size_pretty(table_bytes) as table,
               pg_size_pretty(index_bytes) as index,
               pg_size_pretty(toast_bytes) as toast,
               pg_size_pretty(total_bytes) as total
               FROM public.hypertable_relation_size(main_table);

END;
$$;

alter function hypertable_relation_size_pretty(regclass) owner to postgres;

