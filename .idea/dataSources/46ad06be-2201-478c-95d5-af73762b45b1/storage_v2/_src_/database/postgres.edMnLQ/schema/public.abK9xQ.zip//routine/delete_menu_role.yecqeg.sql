create function delete_menu_role(data json) returns bigint
    language plv8
as
$$
	var o_result;
	sql_str = `delete from MENU_ITEM_ROLE where MENUID = ${data.menuid} and roleid = ${data.roleid}` 
	try {
			  o_result = plv8.execute(sql_str);
	  		}catch(e){
				  }
		return o_result;
$$;

alter function delete_menu_role(json) owner to postgres;

