create function get_departments() returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	str_sql = `SELECT DEPARTMENT FROM DEPARTMENT`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return result_data;

$$;

alter function get_departments() owner to postgres;

