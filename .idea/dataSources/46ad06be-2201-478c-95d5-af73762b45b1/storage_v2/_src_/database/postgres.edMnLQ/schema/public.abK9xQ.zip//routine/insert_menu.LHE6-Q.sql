create function insert_menu(data json) returns bigint
    language plv8
as
$$
	/*
		插入菜单项，v2
	*/
	plv8.elog(NOTICE, JSON.stringify(data));
	try {
		sql_str = data.parentid ? `select (max(orderindex) + 1) as orderindex from menu_item where  parentid =  ${data.parentid}` : `select (max(orderindex) + 1) as orderindex from menu_item where  parentid is null `;
		orderindex = plv8.execute(sql_str)[0]['orderindex'];
	 	orderindex = orderindex ? orderindex: 0;
	} catch(e) {
		return {"meg": e, "sql_str": sql_str, "location": 0};
	}
	
  	try {
		  	textid = Date.now() + Math.floor(Math.random()*(1 - 1000) + 1000);
			sql_str = `insert into TEXT_TRANSLATION(textid, languageid, medium) values (${textid}, 2052, '${data.CHINESE_NAME}')`;
		  	plv8.execute(sql_str);
		  	sql_str = `insert into TEXT_TRANSLATION(textid, languageid, medium) values (${textid}, 1033, '${data.ENGLISH_NAME}')`;
		  	plv8.execute(sql_str);
			sql_str = `INSERT INTO public.menu_item(name, parentid, orderindex, textid) VALUES('${data.CHINESE_NAME}', ${data.parentid}, ${orderindex}, ${textid})`;
		   	var o_result = plv8.execute(sql_str);					  
	  } catch (e) {
			return {"meg": e, "sql_str": sql_str, "location": 1};						   
		 }
	return o_result;
$$;

alter function insert_menu(json) owner to postgres;

