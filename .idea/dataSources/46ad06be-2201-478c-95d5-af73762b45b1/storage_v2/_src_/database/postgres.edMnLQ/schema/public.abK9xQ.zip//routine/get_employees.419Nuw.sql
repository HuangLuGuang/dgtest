create function get_employees(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data = [];
	str_sql = `SELECT E.Id employeeid, E.Name, E.EmployeeNo, E.LoginName, E.Department, D.Facility, D.Company, E.Title, to_char(E.LASTUPDATEON, 'YYYY-MM-DD HH24:MI:SS') as LASTUPDATEON, 
		E.LASTUPDATEDBY, to_char(E.CREATEDON, 'YYYY-MM-DD HH24:MI:SS') as CREATEDON, E.CREATEDBY, E.Resourceid FROM EMPLOYEE E
		LEFT JOIN DEPARTMENT D ON D.DEPARTMENT = E.DEPARTMENT 
		WHERE E.ACTIVE = 1
		LIMIT ${data.limit} OFFSET ${data.offset}`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_employees(json) owner to postgres;

