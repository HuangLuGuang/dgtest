create function update_project(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;

	var str_sql = `update project set projecttext='${data.projecttext}',
		lastupdateon=now(),lastupdatedby='${data.username}' 
		where active=1 and id=${data.id}`;
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'err>>', e);
	}

	return result_data;

$$;

alter function update_project(json) owner to postgres;

