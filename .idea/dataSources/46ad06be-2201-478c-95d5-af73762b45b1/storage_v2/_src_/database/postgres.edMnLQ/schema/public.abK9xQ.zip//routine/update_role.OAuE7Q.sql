create function update_role(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data = JSON.parse(data);
	
	var str_sql = `UPDATE ROLE SET LASTUPDATEON='${data.lastupdateon}', LASTUPDATEDBY='${data.lastupdatedby}', ROLE='${data.role}' WHERE ID=${data.roleid}`
	plv8.elog(NOTICE, 'str_sql_is_exist>>', str_sql);
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function update_role(text) owner to postgres;

