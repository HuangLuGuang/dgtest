create function get_roles(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	
	str_sql = `SELECT ID ROLEID, ROLE, to_char(LASTUPDATEON, 'YYYY-MM-DD HH24:MI:SS') as LASTUPDATEON, LASTUPDATEDBY, 
		to_char(CREATEDON, 'YYYY-MM-DD HH24:MI:SS') as CREATEDON, CREATEDBY FROM ROLE 
		WHERE ACTIVE=1 
		LIMIT ${data.limit} OFFSET ${data.offset}`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_roles(json) owner to postgres;

