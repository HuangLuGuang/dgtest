create function getmenuroles(data json) returns json
    language plv8
as
$$
	var o_result;
	sql_str = `select MIR.ROLEID, R.ROLE,TT.MEDIUM, R.LASTUPDATEON from menu_item_role MIR
		LEFT JOIN role R ON R.ID = MIR.ROLEID
		LEFT JOIN TEXT_TRANSLATION TT on R.TEXTID = TT.TEXTID AND LANGUAGEID=${data.languageid}
		where MENUID=${data.id}` 
	try {
			  o_result = plv8.execute(sql_str);
	  		}catch(e){
				  }
		return o_result;
$$;

alter function getmenuroles(json) owner to postgres;

