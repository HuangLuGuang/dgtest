create function get_role_allocated(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data  = JSON.parse(data);
	
	str_sql = `select R.ID ROLEIDD, R.ROLE, to_char(R.LASTUPDATEON, 'YYYY-MM-DD HH24:MI:SS') as LASTUPDATEON, 
	R.LASTUPDATEDBY, to_char(R.CREATEDON, 'YYYY-MM-DD HH24:MI:SS') as CREATEDON, R.CREATEDBY from employee_role er
	left join role r on er.ROLEID = r.id
	where er.EMPLOYEEID = ${data.employeeid} and er.active=1
	LIMIT ${data.limit} OFFSET ${data.offset}`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_role_allocated(text) owner to postgres;

