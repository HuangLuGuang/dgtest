create function update_employee_resetpassword(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data = JSON.parse(data);
	
	var str_sql = `UPDATE EMPLOYEE SET PASSWORD='${data.password}', LASTUPDATEON=now(), LASTUPDATEDBY='${data.lastupdatedby}' 
	WHERE ID=${data.employeeid} AND ACTIVE=1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function update_employee_resetpassword(text) owner to postgres;

