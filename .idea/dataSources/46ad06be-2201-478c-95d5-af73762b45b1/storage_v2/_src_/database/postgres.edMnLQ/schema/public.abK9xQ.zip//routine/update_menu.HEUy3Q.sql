create function update_menu(data json) returns bigint
    language plv8
as
$$
			try {
				sql_str = `update menu_item set 
						redirecturl = ${data.redirecturl ?  '\'' + data.redirecturl+ '\'':null},
						lastupdatedby = ${data.username ? '\'' + data.username+ '\'':null},
						lastupdateon = now(),
						showdesktop = ${data.showdesktop ? 1: 0},
						showmobile = ${data.showmobile ? 1: 0},
						icon =  ${data.icon ? '\'' + data.icon + '\'':null}
						where id = ${data.id}
					`;
				
				sql_str1 = `update text_translation set medium = '${data.name}' where textid = ${data.name_textid} and languageid = ${data.languageid}`;
			 	plv8.elog(NOTICE, sql_str);
				plv8.elog(NOTICE, sql_str1);
				plv8.execute(sql_str);
				plv8.execute(sql_str1);
	  		}
			catch(e){
				  return 0;
				  }
		return 1;
$$;

alter function update_menu(json) owner to postgres;

