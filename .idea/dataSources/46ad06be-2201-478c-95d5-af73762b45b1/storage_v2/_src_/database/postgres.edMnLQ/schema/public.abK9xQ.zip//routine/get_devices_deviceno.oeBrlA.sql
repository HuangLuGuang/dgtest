create function get_devices_deviceno() returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
		
	str_sql = `SELECT DEVICENO FROM DEVICES WHERE ACTIVE =1`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_devices_deviceno() owner to postgres;

