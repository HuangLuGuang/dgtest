create function time_bucket(bucket_width interval, ts date, "offset" interval) returns date
    immutable
    strict
    parallel safe
    language sql
as
$$
SELECT (public.time_bucket(bucket_width, ts-"offset")+"offset")::date;
$$;

alter function time_bucket(interval, date, interval) owner to postgres;

