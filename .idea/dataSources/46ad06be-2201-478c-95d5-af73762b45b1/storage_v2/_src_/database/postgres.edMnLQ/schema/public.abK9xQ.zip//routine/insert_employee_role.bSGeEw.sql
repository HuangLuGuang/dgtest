create function insert_employee_role(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	var select_data;  // 查询当前用户是否存在employee_role表中
	
	var data = JSON.parse(data);
	
	var str_sql = `SELECT * FROM EMPLOYEE_ROLE WHERE EMPLOYEEID=${data.employeeid} AND ROLEID=${data.roleid} AND ACTIVE=0`
	plv8.elog(NOTICE, 'str_sql_select>>', str_sql);
	try {
		select_data = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'err>>', e);
	}
	
	if (select_data.length) {
		var str_sql = `UPDATE EMPLOYEE_ROLE SET ACTIVE=1, LASTUPDATEON='${data.lastupdateon}', LASTUPDATEDBY='${data.lastupdatedby}' WHERE
		EMPLOYEEID=${data.employeeid} AND ROLEID=${data.roleid} AND ACTIVE=0`
		plv8.elog(NOTICE, 'str_sql_update>>', str_sql);

		try {
			result_data = plv8.execute(str_sql);
		}catch(e) {
			result_data = {"error": e,"sql": str_sql, "location": 1};
		}
	}else {
		var str_sql = `INSERT INTO EMPLOYEE_ROLE(EMPLOYEEID, ROLEID, LASTUPDATEON, LASTUPDATEDBY) VALUES(${data.employeeid}, ${data.roleid}, 
			'${data.lastupdateon}', '${data.lastupdatedby}')`
		plv8.elog(NOTICE, 'str_sql_insert>>', str_sql);

		try {
			result_data = plv8.execute(str_sql);
		}catch(e) {
			result_data = {"error": e,"sql": str_sql, "location": 1};
		}
	}

	return result_data;

$$;

alter function insert_employee_role(text) owner to postgres;

