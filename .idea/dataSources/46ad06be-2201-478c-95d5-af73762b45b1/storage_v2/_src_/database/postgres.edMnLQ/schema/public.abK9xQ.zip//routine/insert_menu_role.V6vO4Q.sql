create function insert_menu_role(data json) returns bigint
    language plv8
as
$$
	var o_result;
	sql_str = `	insert into menu_item_role(menuid, roleid) VALUES(${data.menuid}, ${data.roleid})` 
	try {
			  o_result = plv8.execute(sql_str);
	  		}catch(e){
				  }
		return o_result;
$$;

alter function insert_menu_role(json) owner to postgres;

