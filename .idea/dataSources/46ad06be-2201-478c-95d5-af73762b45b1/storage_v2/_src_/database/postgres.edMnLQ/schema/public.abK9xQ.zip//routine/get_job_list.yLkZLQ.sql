create function get_job_list() returns json
    immutable
    strict
    language plv8
as
$$
	// 添加接口驾驶舱，选择系统下拉框使用
	var result_data;
	str_sql = `SELECT id, jobname FROM public.job_list;`; 
	
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_job_list() owner to postgres;

