create function transaction_history(message json) returns json
    language plv8
as
$$
	sql_str = `INSERT INTO transaction_history(transactionname,transactiontype,transactiontime,functionname,employeeid,division,company,facility,department,workcenter,application,source,machinename,operationcode)
		VALUES(
		${message.transactionname ? '\'' + message.transactionname + '\'' : null},
		${message.transactiontype==0 ? 0 : 1},
		now(),
		${message.functionname ? '\'' + message.functionname + '\'' : null},
		${message.employeeid ?'\'' +   message.employeeid+ '\''  : null},
		${message.division ? '\'' + message.division + '\'' : null},
		${message.company ? '\'' + message.company + '\'' : null},
		${message.facility ? '\'' + message.facility + '\'' : null},
		${message.department ? '\'' + message.department + '\'' : null},
		${message.workcenter ? '\'' + message.workcenter + '\'' : null},
		${message.application ? '\'' + message.application + '\'' : null},
		${message.source ? '\'' + message.source + '\'' : null},
		${message.machinename ? '\'' + message.machinename + '\'' : null},
		${message.operationcode ? '\'' + message.operationcode + '\'' : null}
	)`;
	try {
		plv8.elog(NOTICE, sql_str)
		var s =plv8.execute(sql_str);
		plv8.elog(NOTICE, 's', s)
		return s
	} catch (e) { 
		return e.message
		plv8.elog(NOTICE, e.message)}
$$;

alter function transaction_history(json) owner to postgres;

