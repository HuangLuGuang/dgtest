create function insert_role(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	var is_exist
	
	var data = JSON.parse(data);
	
	var str_sql = `SELECT * FROM ROLE WHERE ROLE='${data.role}'`
	plv8.elog(NOTICE, 'str_sql_is_exist>>', str_sql);
	try {
		is_exist = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'err1>>', e);
	}
	
	if(is_exist.length) {
		var str_sql = `UPDATE ROLE SET ACTIVE=1 WHERE ROLE='${data.role}'`
		plv8.elog(NOTICE, 'str_sql_is_exist>>', str_sql);
		try {
			result_data = plv8.execute(str_sql);
		}catch(e) {
			result_data = {"error": e,"sql": str_sql, "location": 1};
		}
	}else {
		var str_sql = `INSERT INTO ROLE(ROLE, CREATEDON, CREATEDBY) VALUES('${data.role}', '${data.createdon}', '${data.createdby}')`
		plv8.elog(NOTICE, 'str_sql_is_exist>>', str_sql);
		try {
			result_data = plv8.execute(str_sql);
		}catch(e) {
			result_data = {"error": e,"sql": str_sql, "location": 1};
		}
	}

	return result_data;

$$;

alter function insert_role(text) owner to postgres;

