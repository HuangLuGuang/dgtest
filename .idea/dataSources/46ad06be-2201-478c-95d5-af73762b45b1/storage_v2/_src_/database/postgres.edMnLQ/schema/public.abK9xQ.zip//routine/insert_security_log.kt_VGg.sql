create function insert_security_log(message json) returns json
    language plv8
as
$$
	sql_str = `INSERT INTO security_log (application, source, employeeid, logintime, result,  machinename, info,createdby)
		VALUES(
		${message.application ? '\'' + message.application + '\'' : null},
		${message.source ? '\'' + message.source + '\'' : null},
		${message.employeeid ? '\'' + message.employeeid + '\'' : null},
		now(),
		${message.result==0 ? 0 : 1},
		${message.machinename ? '\'' + message.machinename + '\'' : null},
		${message.info ? '\'' + message.info + '\'' : null},
		${message.createdby ? '\'' + message.createdby + '\'' : null}
	)`;
	try {
		plv8.elog(NOTICE, sql_str)
		var s =plv8.execute(sql_str);
		return s
	} catch (e) { 
		return e.message
		plv8.elog(NOTICE, e.message)}
$$;

alter function insert_security_log(json) owner to postgres;

