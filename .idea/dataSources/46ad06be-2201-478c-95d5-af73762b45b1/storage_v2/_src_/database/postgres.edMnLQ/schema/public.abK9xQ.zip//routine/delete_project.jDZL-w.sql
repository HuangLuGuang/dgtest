create function delete_project(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
		
	var str_sql = `update project set active=0,lastupdateon=now(),lastupdatedby='${data.username}' where active=1 and id=${data.id}`;
	plv8.elog(NOTICE, 'str_sql_select>>', str_sql);
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'err>>', e);
	}
	

	return result_data;

$$;

alter function delete_project(json) owner to postgres;

