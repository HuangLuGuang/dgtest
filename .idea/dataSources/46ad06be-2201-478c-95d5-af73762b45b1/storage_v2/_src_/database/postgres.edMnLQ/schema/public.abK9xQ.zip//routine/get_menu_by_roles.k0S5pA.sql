create function get_menu_by_roles(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	str_sql = `select distinct MI.ID, TT.MEDIUM title, MI.PARENTID,MI.REDIRECTURL link, MI.ICON, MI.ORDERINDEX
				from menu_item_role mir
			   left join menu_item MI on mir.menuid = MI.id
			   left join text_translation TT ON TT.TEXTID=MI.TEXTID AND TT.LANGUAGEID=${data.languageid}
			   where 
			   mir.roleid in (${data.roles}) 
				and MI.ACTIVE=1
				order by MI.ORDERINDEX
			  `; 
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return result_data;

$$;

alter function get_menu_by_roles(json) owner to postgres;

