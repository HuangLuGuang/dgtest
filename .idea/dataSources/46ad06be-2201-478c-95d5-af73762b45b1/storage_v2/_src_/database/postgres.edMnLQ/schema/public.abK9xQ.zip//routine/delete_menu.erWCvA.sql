create function delete_menu(data json) returns bigint
    language plv8
as
$$
var _result = plv8.execute(`delete from menu_item where id=${data.id}`);
	return _result;
$$;

alter function delete_menu(json) owner to postgres;

