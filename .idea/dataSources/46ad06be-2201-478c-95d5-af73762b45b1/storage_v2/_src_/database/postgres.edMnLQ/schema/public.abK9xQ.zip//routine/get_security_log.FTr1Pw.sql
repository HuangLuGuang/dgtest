create function get_security_log(parameters json) returns json
    immutable
    strict
    language plv8
as
$$
try{
    var sqlstr = `
    SELECT 
		id,
		employeeid,
		createdby,
		to_char(logintime,'YYYY-MM-DD HH24:MI:SS') AS logintime,
		application,
		CASE result 
		WHEN 1 THEN '成功'
		WHEN 0 THEN '失败'
		END  AS result,
		info,
		source
    FROM security_log
		WHERE active = 1
		ORDER BY id DESC
    limit ${parameters.limit} offset ${parameters.offset}`;
		
    var json_result = plv8.execute(sqlstr);
    return json_result;
		
}catch(e){
    return {"error":e.message,"sql":sqlstr};
}
$$;

alter function get_security_log(json) owner to postgres;

