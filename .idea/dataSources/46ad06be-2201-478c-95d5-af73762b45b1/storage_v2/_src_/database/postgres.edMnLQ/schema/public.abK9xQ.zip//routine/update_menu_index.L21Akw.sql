create function update_menu_index(data json) returns json
    immutable
    strict
    language plv8
as
$$
		// 先查出原来的parentid，对比是否有变化
		try {
			sql_str1 = `select parentid from menu_item where id = ${data.id}`;
			old_parentid = plv8.execute(sql_str1)[0]['parentid'];
		} catch (err) {
			return {"error": err, "sql_str1": sql_str1, "location": 1};
		}
		
		if (old_parentid == data.parentid ) {
			// 如果父id没变化	
			//1判断是序列号是由小变大还是由大变小
			if (data.newindex < data.orderindex) {
				sql_str1 = old_parentid ? `update menu_item set orderindex = orderindex + 1,lastupdateon = now(), lastupdatedby = 'admin' 
							where orderindex >= ${data.newindex} and orderindex < ${data.orderindex} and parentid = ${data.parentid}` :
							`update menu_item set orderindex = orderindex + 1,lastupdateon = now(), lastupdatedby = 'admin' 
							where orderindex >= ${data.newindex} and orderindex < ${data.orderindex} and parentid is null`;
			} else if (data.newindex > data.orderindex) { 
				sql_str1 = old_parentid ? `update menu_item set orderindex = orderindex - 1,lastupdateon = now(), lastupdatedby = 'admin' 
				where orderindex > ${data.orderindex} and orderindex <= ${data.newindex}  and parentid = ${data.parentid}` : 
				`update menu_item set orderindex = orderindex - 1,lastupdateon = now(), lastupdatedby = 'admin' 
				where orderindex > ${data.orderindex} and orderindex <= ${data.newindex}  and parentid is null`;
			}
				sql_str2 = `update menu_item set orderindex = ${data.newindex} where id = ${data.id}`;
			try {
				plv8.execute(sql_str1);
				plv8.execute(sql_str2);
				return 1;
			} catch (err) {
				return {"error": err, "sql_str1": sql_str1, "sql_str2": sql_str2, "location": 2};
			}
		} else {
			// 如果父id变化
				sql_str1 = `update menu_item set orderindex = orderindex + 1,lastupdateon = now(), lastupdatedby = 'admin' 
				where orderindex >= ${data.orderindex}`;
				sql_str1 = `update menu_item set orderindex = ${data.newindex}, parentid=${data.parentid} where id = ${data.id}`;
				try {
					plv8.execute(sql_str1);
					plv8.execute(sql_str1);
					return 1;
				} catch (err) {
								return {"error": err, "sql_str1": sql_str1, "sql_str2": sql_str2, "location": 2};
					}
			}

$$;

alter function update_menu_index(json) owner to postgres;

