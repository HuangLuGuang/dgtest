create function delete_employee_role(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data = JSON.parse(data);
	
	var str_sql = `UPDATE EMPLOYEE_ROLE SET ACTIVE=0, LASTUPDATEON='${data.lastupdateon}', LASTUPDATEDBY='${data.lastupdatedby}' WHERE 
		EMPLOYEEID=${data.employeeid} AND ROLEID=${data.roleid} AND ACTIVE=1`;
		
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function delete_employee_role(text) owner to postgres;

