create function get_menu_items(data json) returns json
    language plv8
as
$$
	sql_str = `
		select MI.ID, MI.TEXTID name_textid, TT.MEDIUM as NAME, MI.ORDERINDEX, '' MENU_DESC, TTT.MEDIUM MENU_TYPE, MI.SHOWDESKTOP, MI.SHOWMOBILE, MI.PARENTID,
		MI.REDIRECTURL, MI.ICON,MI.ACTIVE, MI.LASTUPDATEON, MI.LASTUPDATEDBY from MENU_ITEM MI
		LEFT JOIN text_translation TT ON TT.TEXTID=MI.TEXTID AND TT.LANGUAGEID=${data.languageid}
		LEFT JOIN MENU_ITEM_TYPE MIT ON MIT.ID = MI.TYPE
		LEFT JOIN TEXT_TRANSLATION TTT ON MIT.TEXTID = TTT.TEXTID AND TTT.LANGUAGEID=${data.languageid}
		where MI.ACTIVE=1
		order by MI.ORDERINDEX
	`;
	plv8.elog(NOTICE, sql_str);
    result = plv8.execute(sql_str);
	plv8.elog(NOTICE, sql_str);
	return result;
$$;

alter function get_menu_items(json) owner to postgres;

