create function check_employee_password(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data  = JSON.parse(data);
	
	str_sql = `SELECT * FROM EMPLOYEE 
	WHERE id='${data.employeeid}' AND password='${data.password}' AND ACTIVE=1`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	try {
		result_data = plv8.execute(str_sql);
		if(result_data.length){
			return JSON.stringify(1);   // 密码正确
		}else{
			return JSON.stringify(2);   // 密码错误
		}
	}catch(e) {
		plv8.elog(NOTICE, '验证原始密码有效性错误>>', e);
	}
	
	
	return JSON.stringify(3);

$$;

alter function check_employee_password(text) owner to postgres;

