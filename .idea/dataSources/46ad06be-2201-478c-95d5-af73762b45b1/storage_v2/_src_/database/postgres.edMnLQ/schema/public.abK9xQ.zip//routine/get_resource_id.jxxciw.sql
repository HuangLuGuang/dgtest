create function get_resource_id(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data  = JSON.parse(data);
	
	str_sql = `SELECT ID FROM RESOURCE_ WHERE RESOURCENAME = '${data.employeeno}' AND ACTIVE = 1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, e);
	}
	
	return JSON.stringify(result_data);

$$;

alter function get_resource_id(text) owner to postgres;

