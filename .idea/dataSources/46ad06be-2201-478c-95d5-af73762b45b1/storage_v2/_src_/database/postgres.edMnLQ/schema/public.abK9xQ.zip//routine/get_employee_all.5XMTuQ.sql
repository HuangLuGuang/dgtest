create function get_employee_all(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data  = JSON.parse(data);
	
	str_sql = `SELECT E.ID EMPLOYEEID, E.NAME, PASSWORD, E.EMPLOYEENO, E.LOGINNAME, D.DEPARTMENT, D.COMPANY, D.Facility, E.TITLE, R.ID RID, R.ROLE  FROM EMPLOYEE E
	LEFT JOIN DEPARTMENT D ON E.DEPARTMENT = D.DEPARTMENT
	LEFT JOIN EMPLOYEE_ROLE ER ON E.ID = ER.EMPLOYEEID
	LEFT JOIN ROLE R ON R.ID = ER.ROLEID
	WHERE E.LOGINNAME='${data.loginname}' AND E.ACTIVE=1 AND ER.ACTIVE=1`; 
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_employee_all(text) owner to postgres;

