create function getmenu_with_role_id(data json) returns json
    language plv8
as
$$
// 这就是参数

// str = `select * from role where id='${data.id}'`;
str = `select menuid from menu_item_role where roleid = '${data.id}'`

plv8.elog(NOTICE, str);

// [{"menuid":100000527},{"menuid":100000526},{"menuid":33},{"menuid":40},{"menuid":42},{"menuid":36},{"menuid":100000523},{"menuid":100000529},{"menuid":100000530},{"menuid":21},{"menuid":22},{"menuid":100000528},{"menuid":24},{"menuid":25},{"menuid":18},{"menuid":29},{"menuid":30},{"menuid":100000522},{"menuid":100000589},{"menuid":43},{"menuid":1},{"menuid":100000535},{"menuid":2},{"menuid":3},{"menuid":5},{"menuid":7},{"menuid":8},{"menuid":9},{"menuid":10},{"menuid":15},{"menuid":12},{"menuid":11},{"menuid":13},{"menuid":14},{"menuid":101},{"menuid":116},{"menuid":118},{"menuid":119},{"menuid":117},{"menuid":121},{"menuid":122},{"menuid":123},{"menuid":125},{"menuid":113},{"menuid":112},{"menuid":114},{"menuid":115},{"menuid":120},{"menuid":104},{"menuid":111},{"menuid":124},{"menuid":126},{"menuid":127},{"menuid":128},{"menuid":16},{"menuid":131},{"menuid":132},{"menuid":133},{"menuid":134},{"menuid":135},{"menuid":102},{"menuid":20},{"menuid":103},{"menuid":136}]

result = plv8.execute(str);

for (item of result){
	plv8.elog(NOTICE, item.menuid);
}

return result
$$;

alter function getmenu_with_role_id(json) owner to postgres;

