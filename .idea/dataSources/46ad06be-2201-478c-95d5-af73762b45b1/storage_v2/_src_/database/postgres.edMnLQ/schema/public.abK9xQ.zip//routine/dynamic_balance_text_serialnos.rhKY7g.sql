create function dynamic_balance_text_serialnos() returns json
    immutable
    strict
    language plv8
as
$$
	/*先取出时间范围*/
	
	// time_horizon = plv8.execute('select system.config()')[0]['config']['time_horizon'];
	
	
	str_sql = `SELECT serial_no serialno, max(id) id FROM dynamic_balance_text WHERE active=1
	group by serial_no`; 
	
	result_data = plv8.execute(str_sql);
	
	return result_data;

$$;

alter function dynamic_balance_text_serialnos() owner to postgres;

