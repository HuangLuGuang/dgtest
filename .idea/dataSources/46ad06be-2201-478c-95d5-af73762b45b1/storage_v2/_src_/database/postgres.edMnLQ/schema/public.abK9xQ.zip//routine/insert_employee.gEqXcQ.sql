create function insert_employee(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	var data_exist;
	var data_unused;
	
	var data = JSON.parse(data);
	
	// 查询当前正在使用EMPLOYEE
	var str_sql = `SELECT * FROM EMPLOYEE WHERE LOGINNAME='${data.loginname}' AND ACTIVE=1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	try {
		data_exist = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'str_sql_select1>>', e);
	}
	
	// 查询当前未使用EMPLOYEE
	var str_sql = `SELECT * FROM EMPLOYEE WHERE LOGINNAME='${data.loginname}' AND ACTIVE=0`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	try {
		data_unused = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'str_sql_select2>>', e);
	}
	
	if(data_exist.length) {
		result_data = 2;
		// 删除之前插入的resource_表中数据
		var str_sql = `UPDATE RESOURCE_ SET ACTIVE=0 WHERE RESOURCENAME='${data.employeeno}' AND ACTIVE=1`
		plv8.elog(NOTICE, 'str_sql>>', str_sql);
		try {
			plv8.execute(str_sql);
		}catch(e) {
			plv8.elog(NOTICE, 'str_sql_select2>>', e);
		}
	}else {
		if(data_unused.length) {
			// update操作
			var str_sql = `UPDATE EMPLOYEE SET ACTIVE=1, NAME='${data.name}', employeeno='${data.employeeno}', department='${data.department}', 
			createdon='${data.createdon}', createdby='${data.createdby}', resourceid=${data.resourceid}, title='${data.title}', password='${data.password}'   
			WHERE LOGINNAME='${data.loginname}' AND ACTIVE=0`
			plv8.elog(NOTICE, 'str_sql>>', str_sql);
			try {
				result_data = plv8.execute(str_sql);
			}catch(e) {
				result_data = {"error": e,"sql": str_sql, "location": 1};
			}
		} else {
			// insert操作
			var str_sql = `INSERT INTO EMPLOYEE(name, employeeno, loginname, department, createdon, createdby, resourceid, title, password) VALUES('${data.name}', '${data.employeeno}', 
				'${data.loginname}','${data.department}', '${data.createdon}', '${data.createdby}', ${data.resourceid}, '${data.title}', '${data.password}')`
			plv8.elog(NOTICE, 'str_sql>>', str_sql);
			try {
				result_data = plv8.execute(str_sql);
			}catch(e) {
				result_data = {"error": e,"sql": str_sql, "location": 1};
			}
		}
	}
	
	return result_data;

$$;

alter function insert_employee(text) owner to postgres;

