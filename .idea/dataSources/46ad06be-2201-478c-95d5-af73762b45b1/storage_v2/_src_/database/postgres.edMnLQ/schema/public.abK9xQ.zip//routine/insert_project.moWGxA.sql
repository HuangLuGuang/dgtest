create function insert_project(data json) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	var field_exist;   // 关键字段存在
	var field_exist_inactive;  // 存在失效的关键字段
	
	// 判断关键字段存在
	var str_sql = `select * from project where projectno='${data.projectno}' and active=1`;
	try {
		field_exist = plv8.execute(str_sql);
		if(field_exist.length){
			return 2;
		}
	}catch(e) {
		plv8.elog(NOTICE, 'err>>', e);
	}
	
	// 判断是否存在失效的关键字段
	var str_sql = `select * from project where projectno='${data.projectno}' and active=0`;
	try {
		field_exist_inactive = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'err>>', e);
	}
	
	// 数据操作
	if(field_exist_inactive.length){
		var str_sql = `update project set projecttext='${data.projecttext}',active=1, 
			lastupdateon=now(),lastupdatedby='${data.username}' 
			where active=0 and projectno='${data.projectno}'`;
		
		result_data = plv8.execute(str_sql);
	}else{
		var str_sql = `insert into project(projectno,projecttext,createdby,createdon,lastupdatedby,lastupdateon) 
			values('${data.projectno}', '${data.projecttext}', '${data.username}', now(), '${data.username}', now())`;
			
		result_data = plv8.execute(str_sql);
	}	
		

	return result_data;

$$;

alter function insert_project(json) owner to postgres;

