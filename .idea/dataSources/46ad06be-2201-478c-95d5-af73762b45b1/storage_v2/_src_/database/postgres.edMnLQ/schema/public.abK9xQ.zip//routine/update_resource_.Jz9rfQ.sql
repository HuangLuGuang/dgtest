create function update_resource_(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data = JSON.parse(data);
	
	var str_sql = `UPDATE RESOURCE_ SET NAME='${data.name}', RESOURCENAME='${data.employeeno}', LASTUPDATEON='${data.lastupdateon}', LASTUPDATEDBY='${data.lastupdatedby}' 
	WHERE ID=${data.resourceid} AND ACTIVE=1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function update_resource_(text) owner to postgres;

