create function insert_dynamic_balance_text(data json) returns json
    language plv8
as
$$
  	try {
			sql_str = `INSERT INTO public.dynamic_balance_text(
			test_date, device_no, serial_no, test_attribute, rotate, dynamic_balance1, angle1, dynamic_balance2, angle2, reserved1, reserved2, reserved3, createdon, createdby,lastupdateon, lastupdatedby)
			VALUES ('${data.test_date}', '1700000510', '${data.serial_no}', '${data.test_attribute}', '${data.rotate}','${data.dynamic_balance1}', '${data.angle1}',
					'${data.dynamic_balance2}', '${data.angle2}', '${data.reserved1}', '${data.reserved2}', '${data.reserved3}', now(), 'system', now(), 'system')`
			res = plv8.execute(sql_str);
			return {"result": res, "msg": "successfully"};
	  } catch (e) {
			return {"msg": e, "sql_str": sql_str, "location": 1, "result": 0};						   
		 }
$$;

alter function insert_dynamic_balance_text(json) owner to postgres;

