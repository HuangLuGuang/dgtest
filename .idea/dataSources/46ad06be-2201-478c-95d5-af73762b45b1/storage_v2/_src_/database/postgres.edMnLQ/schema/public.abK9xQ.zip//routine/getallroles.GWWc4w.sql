create function getallroles(data json) returns json
    language plv8
as
$$
	var sql_str = `select R.ID, R.ROLE, TT.MEDIUM from role R
LEFT JOIN TEXT_TRANSLATION TT on R.TEXTID = TT.TEXTID AND LANGUAGEID=${data.languageid} where R.ACTIVE=1`
    var json_result = plv8.execute(sql_str);
	return json_result;
$$;

alter function getallroles(json) owner to postgres;

