create function get_employee_unallocated(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;

	var data  = JSON.parse(data);
	
	str_sql = `select E.ID EMPLOYEEID, E.NAME, E.EMPLOYEENO, E.LOGINNAME, E.DEPARTMENT, E.TITLE from
	((SELECT E.ID EPLOYEEID FROM EMPLOYEE E WHERE E.ACTIVE=1 ) except ( SELECT EMPLOYEEID FROM EMPLOYEE_ROLE WHERE ACTIVE=1 AND ROLEID = ${data.roleid})) NR
	left join EMPLOYEE E on E.id = NR.EPLOYEEID LIMIT ${data.limit} OFFSET ${data.offset}`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	
	return JSON.stringify(result_data);

$$;

alter function get_employee_unallocated(text) owner to postgres;

