create function get_employee_allocated(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data  = JSON.parse(data);
	
	str_sql = `select e.ID EMPLOYEEID, e.NAME, e.EMPLOYEENO, e.LOGINNAME, e.DEPARTMENT, e.TITLE from employee_role er
		left join employee e on er.employeeid = e.id
		where er.ROLEID = ${data.roleid} and er.active=1 and e.ID  is not null
		LIMIT ${data.limit} OFFSET ${data.offset}`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_employee_allocated(text) owner to postgres;

