create function get_project_all_data() returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
		
	str_sql = `SELECT ID,PROJECTNO, PROJECTTEXT,LASTUPDATEDBY,CREATEDBY,
	TO_CHAR(LASTUPDATEON, 'yyyy-mm-dd HH24:MM:SS') LASTUPDATEON,
	TO_CHAR(CREATEDON, 'yyyy-mm-dd HH24:MM:SS') CREATEDON
	FROM PROJECT WHERE ACTIVE=1
	ORDER BY LASTUPDATEON`; 
	
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	result_data = plv8.execute(str_sql);
	
	return JSON.stringify(result_data);

$$;

alter function get_project_all_data() owner to postgres;

