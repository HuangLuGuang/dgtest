create function insert_fileinfo(data json) returns json
    language plv8
as
$$
  	try {
			sql_str = `INSERT INTO public.fileinfo(sourcefilename, actualfilename, absolutepath, url, fileformate, lastupdateon, lastupdatedby, createdon, createdby, deviceno)
			VALUES ('${data.sourcefilename}','${data.actualfilename}','${data.absolutepath}','${data.url}','${data.fileformate}',now(),'${data.username}',now(),'${data.username}', '${data.device_no}')`;
			plv8.elog(NOTICE, sql_str);
			var o_result = plv8.execute(sql_str);	
			return {"result": 1}
	  } catch (e) {
			return {"msg": e, "sql_str": sql_str, "location": 1, "result": 0};						   
		 }
	return o_result;
$$;

alter function insert_fileinfo(json) owner to postgres;

