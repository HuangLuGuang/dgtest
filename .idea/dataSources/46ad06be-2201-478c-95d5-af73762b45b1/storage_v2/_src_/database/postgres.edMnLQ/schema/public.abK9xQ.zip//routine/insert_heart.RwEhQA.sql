create function insert_heart(data json) returns json
    immutable
    strict
    language plv8
as
$$
try {
			sql_str = `SELECT id FROM public.device_control
    		WHERE deviceno='${data.deviceno}'`;
			
			var result_data = plv8.execute(sql_str);
			
	
			sql_str_insert_device_control = `INSERT INTO public.device_control(
			lastupdateon, lastupdatedby, createdon, createdby, deviceno, ipcip, deviceip, padip, heart, device_status, pad_status)
			VALUES (now(), 'system', now(), 'system', '${data.deviceno}','${data.ipc_ip}','${data.deviceip}','${data.pad_ip}',now(),'${data.device_status}','${data.pad_status}')`;
			
			sql_str_update_device_control =`update public.device_control
			SET lastupdateon=now(), lastupdatedby='system', ipcip='${data.ipc_ip}', deviceip='${data.deviceip}', padip='${data.pad_ip}', heart=now(), device_status='${data.device_status}', pad_status='${data.pad_status}'
			WHERE deviceno='${data.deviceno}'`;
			
			sql_str_insert_device_control_log = `INSERT INTO public.device_control_log(
			lastupdateon, lastupdatedby, createdon, createdby, deviceno, ipcip, deviceip, padip, heart, device_status, pad_status)
			VALUES (now(), 'system', now(), 'system', '${data.deviceno}','${data.ipc_ip}','${data.deviceip}','${data.pad_ip}',now(),'${data.device_status}','${data.pad_status}')`;
			
			sql_str_insert_device_control_log = plv8.execute(sql_str_insert_device_control_log);
			if (result_data.length==0) {
			
    		insert_device_control = plv8.execute(sql_str_insert_device_control);
			} else { 
			
    		update_device_control = plv8.execute(sql_str_update_device_control);
			
			}
			
			
			return {"result": sql_str_insert_device_control_log, "msg": "successfully"};
	  } catch (e) {
			return {"msg": e, "sql_str": sql_str, "location": 1, "result": 0};						   
		 }
		 
$$;

alter function insert_heart(json) owner to postgres;

