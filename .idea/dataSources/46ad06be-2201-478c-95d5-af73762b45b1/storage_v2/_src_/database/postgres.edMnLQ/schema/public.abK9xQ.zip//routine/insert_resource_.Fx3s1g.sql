create function insert_resource_(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	var data_exist;
	var data_unused;
	
	var data = JSON.parse(data);
	
	// 查询当前正在使用resourcename
	var str_sql = `SELECT * FROM RESOURCE_ WHERE RESOURCENAME='${data.employeeno}' AND ACTIVE=1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	try {
		data_exist = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'str_sql_select1>>', e);
	}
	
	// 查询当前未使用resourcename
	var str_sql = `SELECT * FROM RESOURCE_ WHERE RESOURCENAME='${data.employeeno}' AND ACTIVE=0`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	try {
		data_unused = plv8.execute(str_sql);
	}catch(e) {
		plv8.elog(NOTICE, 'str_sql_select2>>', e);
	}
	
	if(data_exist.length) {
		result_data = 2;
	}else {
		if(data_unused.length) {
			// update操作
			var str_sql = `UPDATE RESOURCE_ SET NAME='${data.name}', RESOURCETYPE=3, ACTIVE=1 WHERE RESOURCENAME='${data.employeeno}' AND ACTIVE=0`
			plv8.elog(NOTICE, 'str_sql>>', str_sql);

			try {
				result_data = plv8.execute(str_sql);
			}catch(e) {
				result_data = {"error": e,"sql": str_sql, "location": 1};
			}
		} else {
			// insert操作
			var str_sql = `INSERT INTO RESOURCE_(NAME, RESOURCENAME, RESOURCETYPE) VALUES('${data.name}', '${data.employeeno}', 3)`
			plv8.elog(NOTICE, 'str_sql>>', str_sql);

			try {
				result_data = plv8.execute(str_sql);
			}catch(e) {
				result_data = {"error": e,"sql": str_sql, "location": 1};
			}
		}
	}


	return result_data;

$$;

alter function insert_resource_(text) owner to postgres;

