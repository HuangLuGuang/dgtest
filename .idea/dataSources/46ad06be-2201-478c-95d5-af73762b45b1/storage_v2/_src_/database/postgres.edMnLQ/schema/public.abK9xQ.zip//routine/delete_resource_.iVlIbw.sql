create function delete_resource_(data text) returns json
    immutable
    strict
    language plv8
as
$$
	var result_data;
	
	var data = JSON.parse(data);
	
	var str_sql = `UPDATE RESOURCE_ SET ACTIVE=0, LASTUPDATEDBY='${data.username}', LASTUPDATEON=now() WHERE RESOURCENAME='${data.employeeno}' AND ACTIVE=1`
	plv8.elog(NOTICE, 'str_sql>>', str_sql);
	
	try {
		result_data = plv8.execute(str_sql);
	}catch(e) {
		result_data = {"error": e,"sql": str_sql, "location": 1};
	}

	return result_data;

$$;

alter function delete_resource_(text) owner to postgres;

