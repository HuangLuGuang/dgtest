create function insert_map_wiporder_pressed_curve(data json) returns json
    language plv8
as
$$
	/*
		保存轮对压装机压装曲线开始和结束时间
	*/
	
	try {
		sql_str1 = `update public.map_wiporder_pressed_curve set active=0 where wiporderno='${data.wiporderno}' and wipordertype=${data.wipordertype} and oprsequenceno='${data.oprsequenceno}'`;
		sql_str2 = `INSERT INTO public.map_wiporder_pressed_curve(wiporderno, wipordertype, oprsequenceno,deviceno, startdate, enddate, lastupdateon, lastupdatedby, createdon, createdby)
			VALUES ('${data.wiporderno}',${data.wipordertype},'${data.oprsequenceno}','${data.deviceno}','${data.startdate}','${data.startdate}',now(),'system',now(),'system')`;
		plv8.elog(NOTICE, sql_str1);
		plv8.elog(NOTICE, sql_str2);
		plv8.execute(sql_str1);
		plv8.execute(sql_str2);
		return {"result": 1, "msg":"successfully"};
	} catch (e) { 
		return {"result": 0, "msg": e};
		plv8.elog(NOTICE, e.message);
	}
$$;

alter function insert_map_wiporder_pressed_curve(json) owner to postgres;

